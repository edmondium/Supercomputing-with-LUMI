// Simple C++ program to display "Hello World"

// Header file for input output functions
#include <iostream>

// main function -
// where the execution of program begins
int main()
{

    // prints hello world
    std::cout << "Hello, World!" << std::endl;

    return 0;

}
